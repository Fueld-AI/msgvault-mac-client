import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: EmailStore
    @State private var selectedTab: SidebarTab = .search
    
    enum SidebarTab: String, CaseIterable {
        case search = "Search"
        case senders = "Top Senders"
        case stats = "Stats"
        case settings = "Settings"
        
        var icon: String {
            switch self {
            case .search: return "magnifyingglass"
            case .senders: return "person.2"
            case .stats: return "chart.bar"
            case .settings: return "gear"
            }
        }
    }
    
    var body: some View {
        NavigationSplitView {
            // Sidebar
            VStack(spacing: 0) {
                // Brand header
                HStack(spacing: 8) {
                    Image(systemName: "envelope.badge.shield.half.filled")
                        .font(.title2)
                        .foregroundStyle(.teal)
                    Text("MsgVault")
                        .font(.title3.bold())
                        .foregroundStyle(.primary)
                }
                .padding(.vertical, 16)
                .padding(.horizontal)
                
                Divider()
                
                // Nav items
                List(SidebarTab.allCases, id: \.self, selection: $selectedTab) { tab in
                    Label(tab.rawValue, systemImage: tab.icon)
                        .tag(tab)
                }
                .listStyle(.sidebar)
            }
            .frame(minWidth: 180)
            
        } detail: {
            // Main content
            switch selectedTab {
            case .search:
                SearchView()
            case .senders:
                SendersView()
            case .stats:
                StatsView()
            case .settings:
                SettingsView()
            }
        }
        .frame(minWidth: 900, minHeight: 600)
    }
}

// MARK: - Search View

struct SearchView: View {
    @EnvironmentObject var store: EmailStore
    @State private var searchText = ""
    @State private var selectedMessageId: String?
    
    var body: some View {
        HSplitView {
            // Message list
            VStack(spacing: 0) {
                // Search bar
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    
                    TextField("Search emails... (e.g. from:john subject:invoice)", text: $searchText)
                        .textFieldStyle(.plain)
                        .font(.body)
                        .onSubmit {
                            Task { await store.search(query: searchText) }
                        }
                    
                    if !searchText.isEmpty {
                        Button {
                            searchText = ""
                            store.searchResults = []
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    Button("Search") {
                        Task { await store.search(query: searchText) }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.teal)
                    .controlSize(.small)
                }
                .padding(12)
                .background(.bar)
                
                Divider()
                
                // Results
                if store.isLoading {
                    Spacer()
                    ProgressView("Searching...")
                        .frame(maxWidth: .infinity)
                    Spacer()
                } else if store.searchResults.isEmpty {
                    Spacer()
                    VStack(spacing: 12) {
                        Image(systemName: "envelope.open")
                            .font(.system(size: 48))
                            .foregroundStyle(.tertiary)
                        Text(searchText.isEmpty ? "Enter a search query to find emails" : "No results found")
                            .foregroundStyle(.secondary)
                        Text("Supports Gmail-like syntax: from:, to:, subject:, has:attachment, before:, after:")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                    Spacer()
                } else {
                    List(store.searchResults, selection: $selectedMessageId) { message in
                        MessageRowView(message: message)
                            .tag(message.id)
                    }
                    .listStyle(.inset)
                    .onChange(of: selectedMessageId) { _, newId in
                        if let id = newId {
                            store.selectedMessage = store.searchResults.first(where: { $0.id == id })
                            Task { await store.loadMessageDetail(id: id) }
                        }
                    }
                }
                
                // Status bar
                HStack {
                    if let error = store.errorMessage {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundStyle(.orange)
                        Text(error)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else if !store.searchResults.isEmpty {
                        Text("\(store.searchResults.count) messages found")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(.bar)
            }
            .frame(minWidth: 350, idealWidth: 450)
            
            // Detail pane
            MessageDetailView()
                .frame(minWidth: 350, idealWidth: 500)
        }
    }
}

// MARK: - Message Row

struct MessageRowView: View {
    let message: EmailMessage
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(message.from)
                    .font(.headline)
                    .lineLimit(1)
                Spacer()
                Text(formatDate(message.date))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Text(message.subject)
                .font(.subheadline)
                .foregroundStyle(.primary)
                .lineLimit(1)
            
            if !message.snippet.isEmpty {
                Text(message.snippet)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            
            HStack(spacing: 4) {
                if message.hasAttachment {
                    Image(systemName: "paperclip")
                        .font(.caption2)
                        .foregroundStyle(.teal)
                }
                ForEach(message.labels.prefix(3), id: \.self) { label in
                    Text(label)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.teal.opacity(0.12))
                        .foregroundStyle(.teal)
                        .clipShape(Capsule())
                }
            }
        }
        .padding(.vertical, 4)
    }
    
    private func formatDate(_ dateStr: String) -> String {
        // Try to make the date more readable
        if dateStr.count > 10 {
            return String(dateStr.prefix(10))
        }
        return dateStr
    }
}

// MARK: - Message Detail

struct MessageDetailView: View {
    @EnvironmentObject var store: EmailStore
    
    var body: some View {
        if let message = store.selectedMessage {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text(message.subject)
                            .font(.title2.bold())
                        
                        HStack(spacing: 16) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("From")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text(message.from)
                                    .font(.body)
                            }
                            
                            if !message.to.isEmpty {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("To")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text(message.to)
                                        .font(.body)
                                        .lineLimit(2)
                                }
                            }
                            
                            Spacer()
                            
                            VStack(alignment: .trailing, spacing: 2) {
                                Text("Date")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text(message.date)
                                    .font(.body)
                            }
                        }
                        
                        if !message.labels.isEmpty {
                            HStack(spacing: 4) {
                                ForEach(message.labels, id: \.self) { label in
                                    Text(label)
                                        .font(.caption)
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(.teal.opacity(0.12))
                                        .foregroundStyle(.teal)
                                        .clipShape(Capsule())
                                }
                            }
                        }
                    }
                    .padding()
                    .background(.background.secondary)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    Divider()
                    
                    // Body
                    if !store.messageDetail.isEmpty {
                        Text(store.messageDetail)
                            .font(.body)
                            .textSelection(.enabled)
                    } else {
                        ProgressView()
                    }
                }
                .padding()
            }
        } else {
            VStack(spacing: 12) {
                Image(systemName: "envelope.open")
                    .font(.system(size: 48))
                    .foregroundStyle(.tertiary)
                Text("Select a message to view details")
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// MARK: - Senders View

struct SendersView: View {
    @EnvironmentObject var store: EmailStore
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Top Senders")
                    .font(.title2.bold())
                Spacer()
                Button("Refresh") {
                    Task { await store.loadTopSenders() }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
            .padding()
            .background(.bar)
            
            Divider()
            
            if store.isLoading {
                Spacer()
                ProgressView("Loading senders...")
                Spacer()
            } else if store.senders.isEmpty {
                Spacer()
                VStack(spacing: 12) {
                    Image(systemName: "person.2")
                        .font(.system(size: 48))
                        .foregroundStyle(.tertiary)
                    Text("Click Refresh to load top senders")
                        .foregroundStyle(.secondary)
                }
                Spacer()
            } else {
                List(store.senders) { sender in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(sender.name)
                                .font(.headline)
                            if sender.email != sender.name {
                                Text(sender.email)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Text("\(sender.count)")
                            .font(.title3.monospacedDigit())
                            .foregroundStyle(.teal)
                        Text("msgs")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        if !sender.totalSize.isEmpty {
                            Text(sender.totalSize)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(width: 60, alignment: .trailing)
                        }
                    }
                    .padding(.vertical, 4)
                }
                .listStyle(.inset)
            }
        }
        .task {
            if store.senders.isEmpty {
                await store.loadTopSenders()
            }
        }
    }
}

// MARK: - Stats View

struct StatsView: View {
    @EnvironmentObject var store: EmailStore
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Archive Statistics")
                    .font(.title2.bold())
                Spacer()
                Button("Refresh") {
                    Task { await store.loadStats() }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
            .padding()
            .background(.bar)
            
            Divider()
            
            if store.isLoading {
                Spacer()
                ProgressView("Loading stats...")
                Spacer()
            } else if let stats = store.statsInfo {
                ScrollView {
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                    ], spacing: 16) {
                        StatCard(title: "Total Messages", value: "\(stats.totalMessages)", icon: "envelope.fill", color: .teal)
                        StatCard(title: "Accounts", value: "\(stats.totalAccounts)", icon: "person.crop.circle", color: .blue)
                        StatCard(title: "Attachments", value: "\(stats.totalAttachments)", icon: "paperclip", color: .orange)
                        StatCard(title: "Database Size", value: stats.dbSize, icon: "internaldrive", color: .purple)
                    }
                    .padding()
                    
                    if !stats.lastSync.isEmpty {
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .foregroundStyle(.secondary)
                            Text("Last sync: \(stats.lastSync)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                    }
                }
            } else {
                Spacer()
                VStack(spacing: 12) {
                    Image(systemName: "chart.bar")
                        .font(.system(size: 48))
                        .foregroundStyle(.tertiary)
                    Text("Click Refresh to load archive statistics")
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
        }
        .task {
            if store.statsInfo == nil {
                await store.loadStats()
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title)
                .foregroundStyle(color)
                .frame(width: 44, height: 44)
                .background(color.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            
            Text(value)
                .font(.title.bold().monospacedDigit())
            
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .background(.background.secondary)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Settings View

struct SettingsView: View {
    @EnvironmentObject var store: EmailStore
    @State private var binaryPath: String = ""
    @State private var testResult: String = ""
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Settings")
                    .font(.title2.bold())
                Spacer()
            }
            .padding()
            .background(.bar)
            
            Divider()
            
            Form {
                Section("msgvault Binary") {
                    TextField("Path to msgvault", text: $binaryPath)
                        .onAppear { binaryPath = store.msgvaultPath }
                    
                    HStack {
                        Button("Test Connection") {
                            store.msgvaultPath = binaryPath
                            Task {
                                do {
                                    let output = try store.runTestCommand()
                                    testResult = "✅ Connected — \(output.prefix(200))"
                                } catch {
                                    testResult = "❌ Error: \(error.localizedDescription)"
                                }
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.teal)
                        
                        Button("Save") {
                            store.msgvaultPath = binaryPath
                            testResult = "Path saved."
                        }
                        .buttonStyle(.bordered)
                    }
                    
                    if !testResult.isEmpty {
                        Text(testResult)
                            .font(.caption)
                            .foregroundStyle(testResult.hasPrefix("✅") ? .green : .red)
                            .textSelection(.enabled)
                    }
                }
                
                Section("Info") {
                    LabeledContent("Config location") {
                        Text("~/.msgvault/config.toml")
                            .textSelection(.enabled)
                    }
                    LabeledContent("Data directory") {
                        Text("~/.msgvault/")
                            .textSelection(.enabled)
                    }
                }
                
                Section("Search Syntax Help") {
                    VStack(alignment: .leading, spacing: 6) {
                        syntaxRow("from:john@example.com", "Messages from a sender")
                        syntaxRow("to:jane@example.com", "Messages to a recipient")
                        syntaxRow("subject:invoice", "Subject contains word")
                        syntaxRow("has:attachment", "Messages with attachments")
                        syntaxRow("after:2024-01-01", "Messages after date")
                        syntaxRow("before:2024-12-31", "Messages before date")
                        syntaxRow("label:INBOX", "Messages with label")
                        syntaxRow("project update", "Full-text search")
                    }
                    .font(.system(.caption, design: .monospaced))
                }
            }
            .formStyle(.grouped)
        }
    }
    
    private func syntaxRow(_ syntax: String, _ description: String) -> some View {
        HStack {
            Text(syntax)
                .foregroundStyle(.teal)
                .frame(width: 200, alignment: .leading)
            Text(description)
                .foregroundStyle(.secondary)
        }
    }
}

// Add a test method to the store
extension EmailStore {
    func runTestCommand() throws -> String {
        let process = Process()
        let pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: msgvaultPath)
        process.arguments = ["stats"]
        process.standardOutput = pipe
        process.standardError = pipe
        
        var env = ProcessInfo.processInfo.environment
        env["HOME"] = NSHomeDirectory()
        process.environment = env
        
        try process.run()
        process.waitUntilExit()
        
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        return String(data: data, encoding: .utf8) ?? "No output"
    }
}

#Preview {
    ContentView()
        .environmentObject(EmailStore())
}
