import Foundation
import SwiftUI

// MARK: - Models

struct EmailMessage: Identifiable, Hashable {
    let id: String
    let from: String
    let to: String
    let subject: String
    let date: String
    let snippet: String
    let labels: [String]
    let hasAttachment: Bool
    
    // Parse from msgvault search --json output
    static func parse(from json: [String: Any]) -> EmailMessage? {
        guard let id = json["id"] as? String ?? json["message_id"] as? String else { return nil }
        return EmailMessage(
            id: id,
            from: json["from"] as? String ?? json["sender"] as? String ?? "Unknown",
            to: json["to"] as? String ?? json["recipients"] as? String ?? "",
            subject: json["subject"] as? String ?? "(no subject)",
            date: json["date"] as? String ?? json["internal_date"] as? String ?? "",
            snippet: json["snippet"] as? String ?? json["body_preview"] as? String ?? "",
            labels: json["labels"] as? [String] ?? [],
            hasAttachment: json["has_attachment"] as? Bool ?? false
        )
    }
}

struct SenderAggregate: Identifiable {
    let id = UUID()
    let name: String
    let email: String
    let count: Int
    let totalSize: String
}

struct StatsInfo {
    let totalMessages: Int
    let totalAccounts: Int
    let totalAttachments: Int
    let dbSize: String
    let lastSync: String
}

// MARK: - Email Store

@MainActor
class EmailStore: ObservableObject {
    @Published var searchResults: [EmailMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var statsInfo: StatsInfo?
    @Published var selectedMessage: EmailMessage?
    @Published var messageDetail: String = ""
    @Published var senders: [SenderAggregate] = []
    
    // Path to msgvault binary - adjust if needed
    var msgvaultPath: String = "/usr/local/bin/msgvault"
    
    init() {
        // Try to find msgvault
        findMsgvault()
    }
    
    private func findMsgvault() {
        // Check common install locations
        let paths = [
            "/usr/local/bin/msgvault",
            "/opt/homebrew/bin/msgvault",
            "\(NSHomeDirectory())/.local/bin/msgvault",
            "\(NSHomeDirectory())/go/bin/msgvault"
        ]
        for path in paths {
            if FileManager.default.fileExists(atPath: path) {
                msgvaultPath = path
                return
            }
        }
        // Try which
        if let result = try? runCommand("/usr/bin/which", arguments: ["msgvault"]),
           !result.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            msgvaultPath = result.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    // MARK: - Command Runner
    
    private func runCommand(_ command: String, arguments: [String] = []) throws -> String {
        let process = Process()
        let pipe = Pipe()
        let errorPipe = Pipe()
        
        process.executableURL = URL(fileURLWithPath: command)
        process.arguments = arguments
        process.standardOutput = pipe
        process.standardError = errorPipe
        
        // Pass through environment including HOME for msgvault config
        var env = ProcessInfo.processInfo.environment
        env["HOME"] = NSHomeDirectory()
        process.environment = env
        
        try process.run()
        process.waitUntilExit()
        
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
        
        if process.terminationStatus != 0 {
            let errorString = String(data: errorData, encoding: .utf8) ?? "Unknown error"
            throw MsgVaultError.commandFailed(errorString)
        }
        
        return String(data: data, encoding: .utf8) ?? ""
    }
    
    private func runMsgvault(arguments: [String]) throws -> String {
        try runCommand(msgvaultPath, arguments: arguments)
    }
    
    // MARK: - Search
    
    func search(query: String) async {
        guard !query.isEmpty else {
            searchResults = []
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let output = try runMsgvault(arguments: ["search", query, "--json", "--limit", "100"])
            let messages = parseSearchResults(output)
            searchResults = messages
        } catch {
            errorMessage = "Search failed: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    // MARK: - Stats
    
    func loadStats() async {
        isLoading = true
        do {
            let output = try runMsgvault(arguments: ["stats"])
            statsInfo = parseStats(output)
        } catch {
            errorMessage = "Failed to load stats: \(error.localizedDescription)"
        }
        isLoading = false
    }
    
    // MARK: - Senders
    
    func loadTopSenders() async {
        isLoading = true
        do {
            let output = try runMsgvault(arguments: ["list-senders", "--limit", "50"])
            senders = parseSenders(output)
        } catch {
            errorMessage = "Failed to load senders: \(error.localizedDescription)"
        }
        isLoading = false
    }
    
    // MARK: - Message Detail
    
    func loadMessageDetail(id: String) async {
        do {
            let output = try runMsgvault(arguments: ["show", id])
            messageDetail = output
        } catch {
            messageDetail = "Failed to load message: \(error.localizedDescription)"
        }
    }
    
    // MARK: - Parsers
    
    private func parseSearchResults(_ output: String) -> [EmailMessage] {
        // msgvault search --json outputs one JSON object per line (JSONL)
        var messages: [EmailMessage] = []
        
        // First try parsing as a JSON array
        if let data = output.data(using: .utf8),
           let jsonArray = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            for json in jsonArray {
                if let msg = EmailMessage.parse(from: json) {
                    messages.append(msg)
                }
            }
            return messages
        }
        
        // Otherwise try JSONL (one object per line)
        let lines = output.components(separatedBy: .newlines)
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard !trimmed.isEmpty else { continue }
            if let data = trimmed.data(using: .utf8),
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let msg = EmailMessage.parse(from: json) {
                messages.append(msg)
            }
        }
        
        // If JSON parsing fails entirely, try parsing the text output
        if messages.isEmpty && !output.isEmpty {
            messages = parseTextSearchResults(output)
        }
        
        return messages
    }
    
    private func parseTextSearchResults(_ output: String) -> [EmailMessage] {
        // Fallback: parse the non-JSON text output
        // msgvault search typically shows results like:
        // [date] From: sender Subject: subject
        var messages: [EmailMessage] = []
        let lines = output.components(separatedBy: .newlines)
        var currentId = 0
        
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard !trimmed.isEmpty else { continue }
            
            // Try to extract basic info from each result line
            currentId += 1
            messages.append(EmailMessage(
                id: "text-\(currentId)",
                from: extractField(from: trimmed, field: "From:") ?? "",
                to: extractField(from: trimmed, field: "To:") ?? "",
                subject: extractField(from: trimmed, field: "Subject:") ?? trimmed,
                date: extractDatePrefix(from: trimmed) ?? "",
                snippet: trimmed,
                labels: [],
                hasAttachment: false
            ))
        }
        return messages
    }
    
    private func extractField(from line: String, field: String) -> String? {
        guard let range = line.range(of: field) else { return nil }
        let after = line[range.upperBound...].trimmingCharacters(in: .whitespaces)
        // Take until next known field or end of line
        let nextFields = ["From:", "To:", "Subject:", "Date:"]
        for next in nextFields where next != field {
            if let nextRange = after.range(of: next) {
                return String(after[..<nextRange.lowerBound]).trimmingCharacters(in: .whitespaces)
            }
        }
        return String(after)
    }
    
    private func extractDatePrefix(from line: String) -> String? {
        // Try to match a date at the start like [2024-01-15] or 2024-01-15
        let pattern = #"^\[?(\d{4}-\d{2}-\d{2}[T\s]?\d{0,2}:?\d{0,2}:?\d{0,2})\]?"#
        if let regex = try? NSRegularExpression(pattern: pattern),
           let match = regex.firstMatch(in: line, range: NSRange(line.startIndex..., in: line)),
           let range = Range(match.range(at: 1), in: line) {
            return String(line[range])
        }
        return nil
    }
    
    private func parseStats(_ output: String) -> StatsInfo {
        // Parse the text output from msgvault stats
        var total = 0
        var accounts = 0
        var attachments = 0
        var dbSize = ""
        var lastSync = ""
        
        let lines = output.components(separatedBy: .newlines)
        for line in lines {
            let lower = line.lowercased()
            if lower.contains("message") && lower.contains("total") {
                total = extractNumber(from: line) ?? 0
            } else if lower.contains("account") {
                accounts = extractNumber(from: line) ?? 0
            } else if lower.contains("attachment") {
                attachments = extractNumber(from: line) ?? 0
            } else if lower.contains("database") || lower.contains("size") {
                dbSize = extractValue(from: line) ?? ""
            } else if lower.contains("sync") || lower.contains("last") {
                lastSync = extractValue(from: line) ?? ""
            }
        }
        
        return StatsInfo(
            totalMessages: total,
            totalAccounts: accounts,
            totalAttachments: attachments,
            dbSize: dbSize,
            lastSync: lastSync
        )
    }
    
    private func parseSenders(_ output: String) -> [SenderAggregate] {
        var result: [SenderAggregate] = []
        let lines = output.components(separatedBy: .newlines)
        
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard !trimmed.isEmpty else { continue }
            
            // Typical format: count  email/name  size
            let parts = trimmed.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
            guard parts.count >= 2 else { continue }
            
            // Try to parse - first or last element might be the count
            if let count = Int(parts[0]) {
                let name = parts.dropFirst().dropLast().joined(separator: " ")
                let size = parts.last ?? ""
                result.append(SenderAggregate(
                    name: name,
                    email: name,
                    count: count,
                    totalSize: size
                ))
            }
        }
        return result
    }
    
    private func extractNumber(from line: String) -> Int? {
        let pattern = #"[\d,]+"#
        if let regex = try? NSRegularExpression(pattern: pattern),
           let match = regex.firstMatch(in: line, range: NSRange(line.startIndex..., in: line)),
           let range = Range(match.range, in: line) {
            let numStr = String(line[range]).replacingOccurrences(of: ",", with: "")
            return Int(numStr)
        }
        return nil
    }
    
    private func extractValue(from line: String) -> String? {
        if let colonIndex = line.firstIndex(of: ":") {
            return String(line[line.index(after: colonIndex)...]).trimmingCharacters(in: .whitespaces)
        }
        return nil
    }
}

// MARK: - Errors

enum MsgVaultError: LocalizedError {
    case commandFailed(String)
    case notFound
    
    var errorDescription: String? {
        switch self {
        case .commandFailed(let msg): return msg
        case .notFound: return "msgvault binary not found"
        }
    }
}
